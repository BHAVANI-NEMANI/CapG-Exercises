package com.cg.dao;

import com.cg.model.Bank;

public interface Dao {

	Bank save1(Bank b);

	String showBal(long acnum);

	void deposit1(long acn, double m);

	void withdraw1(long acno2, double m1);

	double transfer1(long facno, long tacno, long m2);

}
