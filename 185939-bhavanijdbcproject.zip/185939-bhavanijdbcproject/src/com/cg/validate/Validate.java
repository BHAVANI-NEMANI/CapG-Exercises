package com.cg.validate;

public class Validate {
public boolean name(String str) {
		
		boolean name_val = str.matches("[A-Z][a-z]*");
		if(name_val)
			return true;
		return false;
		
	}

}
