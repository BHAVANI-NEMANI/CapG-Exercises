package com.cg.service;

import java.util.Scanner;

import com.cg.dao.Dao;
import com.cg.dao.DaoImpl;
import com.cg.model.Bank;
import com.cg.validate.Validate;

public class ServiceImpl implements Service {
	
	private static Dao dao = new DaoImpl();
	private static Validate val = new Validate();
	private static Scanner sc = new Scanner(System.in);

	@Override
	public Bank create() {
		// TODO Auto-generated method stub
	Bank b = new Bank();
	System.out.println("Enter Account number:");
       int i = sc.nextInt();
       b.setAnum(i);
		System.out.println("Enter respective Name:");
		String str = sc.next();
		if(val.name(str))
			b.setAname(str);
		else {
			System.out.println("Please start your  Name with capital letter");
			System.exit(0);
		}
		System.out.println("Enter money to be deposited");
		b.setBal(sc.nextDouble());
		return dao.save1(b);	
		
		
	}

	@Override
	public String show(long acnum) {
		return dao.showBal(acnum);
		
	}

	@Override
	public void deposit(long acn, double m) {
		dao.deposit1(acn, m);
		
	}

	@Override
	public void withdraw(long acno2, double m1) {
		System.out.println("Enter amount to be withdrawn:");
		dao.withdraw1(acno2, m1);
		
	}

	@Override
	public double balTranfer(long facno, long tacno, long m2) {
		
		return dao.transfer1(facno, tacno, m2);
	
	}

}
