package com.cg.service;

import com.cg.model.Bank;

public interface Service {

	Bank create();

	String show(long acnum);

	void deposit(long acn, double m);

	void withdraw(long acno2, double m1);

	double balTranfer(long facno, long tacno, long m2);

}
