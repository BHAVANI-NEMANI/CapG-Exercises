package com.cg.ui;

import java.util.Scanner;

import com.cg.service.Service;
import com.cg.service.ServiceImpl;

public class Main {
	private static Service service = new ServiceImpl();
	private static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		
		
		String ch = "yes";
		while(ch.equals("yes"))
		{
			System.out.println("Please enter your choice \n\n1. Create Bank Account\n2. Show Balance\n3. Deposit\n4. Withdraw\n5. Fund Transfer\n");
			int choice = sc.nextInt();
			switch(choice)
			{
			
			case 1 : 
				service.create();
				break;
			case 2 :
				System.out.println("Enter Account Number to get balance:");
				long acno = sc.nextLong();
				System.out.println("The Account details are:\n"+service.show(acno));
				break;
			case 3 :
				System.out.println("Enter Account Number to get deposited:");
				long acno1 = sc.nextLong();
				System.out.println("Enter the amount to get deposited:");
				double m = sc.nextDouble();
				service.deposit(acno1, m);
				break;
			case 4 :
				System.out.println("Enter Account Number to be withdrawn:");
				long acno2 = sc.nextLong();
				System.out.println("Enter Amount to be withdraw:");
				double m1 = sc.nextDouble();
				service.withdraw(acno2, m1);
				break;
			case 5 :
				System.out.println("Enter your Account Number:");
				long facno = sc.nextLong();
				System.out.println("Enter recipient Account Number:");
				long tacno = sc.nextLong();
				System.out.println("Enter ammount to be transfered to the respective account:");
				long m2 = sc.nextLong();
				System.out.println(service.balTranfer(facno, tacno,m2));
				break;
			default :
				System.out.println("Please enter a valid choice");
				break;
	
			}
			System.out.println("Do you want to continue the process: yes or no");
			ch=sc.next();
		}
	}


}
