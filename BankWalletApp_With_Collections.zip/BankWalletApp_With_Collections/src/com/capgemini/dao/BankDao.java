package com.capgemini.dao;

import java.util.List;

import com.capgemini.exception.InsufficientBalanceException;
import com.capgemini.model.Account;

public interface BankDao 
{
	  boolean saveAccount(Account a);
	  long viewBalance(String accountNo,String pin);
	  long depositCash(String accountNo,long amount);
	  long withdrawCash(String accountNo,String pin,long amount) throws InsufficientBalanceException;
	  boolean tranferMoney(String sourceAcNo,String destAcNo,long amount,String pin) throws InsufficientBalanceException;
	  List<String> showTransactions(String accountNo,String pin);
}
