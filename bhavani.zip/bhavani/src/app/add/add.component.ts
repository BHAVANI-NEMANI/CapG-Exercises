import { Component, OnInit } from '@angular/core';
import { Employee } from '../Employee';
import { EmployeeService } from '../employee.service';
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  empList: any = [];
  emp: Employee = new Employee();

  

  



  
  constructor(private employeeService: EmployeeService) {
    this.employeeService.getEmpDetails().subscribe(data => this.empList = data);
  }

  ngOnInit() {
  }

  
  imgsrc: string = "./assets/images.jpg";
  imgsrc1: string = "./assets/girl.jpg";


  insert(data) {
    alert(`Id: ${data.id}  Employee Name: ${data.name} Email: ${data.email} Phone: ${data.phone}`);
    this.emp.id = data.id;
    this.emp.name = data.name;
    this.emp.email = data.email;
    this.emp.phone = data.phone;
    console.log(this.emp);
    this.employeeService.setEmpDetails(this.emp);
  }
  show(data): void {
    alert(`Employee Added\nId: ${data.id} Name: ${data.name} Author: ${data.email} Genre: ${data.phone}`);
  }
  
}
