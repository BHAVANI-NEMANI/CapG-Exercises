package com.cg.springwithangular.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.springwithangular.beans.Country;
import com.cg.springwithangular.db.CountryDb;


@Repository
public class IcountryDaoImpl implements IcountryDao{

	@Override
	public List<Country> getAllCountries() {
		
		return CountryDb.getCountryList();
	}

	@Override
	public void addCountry(Country country) {
		 CountryDb.getCountryList().add(country);
		
		
	}

	@Override
	public Country deleteCountry(int id) {
		
		return  CountryDb.getCountryList().remove(id);
	}

	@Override
	public Country searchCountry(int id) {
		
		return (Country) CountryDb.getCountryList().stream();
	}

}
