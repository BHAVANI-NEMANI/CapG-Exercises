package com.cg.springwithangular.beans;

public class Country {

	private int id;
	private String name;
	private String population;
	
	
	
	public Country(int id, String name, String population) {
		super();
		this.id = id;
		this.name = name;
		this.population = population;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPopulation() {
		return population;
	}
	public void setPopulation(String population) {
		this.population = population;
	}
	@Override
	public String toString() {
		return "Country [id=" + id + ", name=" + name + ", population="
				+ population + "]";
	}
	
}
