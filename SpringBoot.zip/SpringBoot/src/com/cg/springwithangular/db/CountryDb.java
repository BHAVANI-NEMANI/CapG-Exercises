package com.cg.springwithangular.db;


import java.util.ArrayList;

import com.cg.springwithangular.beans.Country;

public class CountryDb {
private static ArrayList<Country> countryList= new ArrayList<Country>(); 


static{
	countryList.add(new Country(101,"Indai","612735"));
	countryList.add(new Country(102,"In","6135"));
	countryList.add(new Country(103,"Iai","62735"));
	
}


public static ArrayList<Country> getCountryList() {
	return countryList;
}


public static void setCountryList(ArrayList<Country> countryList) {
	CountryDb.countryList = countryList;
}
}
