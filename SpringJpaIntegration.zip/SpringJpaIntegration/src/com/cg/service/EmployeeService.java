package com.cg.service;

import java.util.List;

import com.cg.entities.MyEmployee;

public interface EmployeeService {
	
	
	public abstract MyEmployee save(MyEmployee employee);
	
	public abstract List<MyEmployee> loadAll();
}
