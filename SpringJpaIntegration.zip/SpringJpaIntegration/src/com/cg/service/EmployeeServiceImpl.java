package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.EmployeeDao;
import com.cg.entities.MyEmployee;
@Service
@Transactional
public class EmployeeServiceImpl  implements EmployeeService{

	@Autowired
	EmployeeDao employeeDao;
	
	@Override
	public MyEmployee save(MyEmployee employee) {
		// TODO Auto-generated method stub
		
		return employeeDao.save(employee);
		 
	}

	@Override
	public List<MyEmployee> loadAll() {
		// TODO Auto-generated method stub
		return employeeDao.loadAll();
		 
	}

}
