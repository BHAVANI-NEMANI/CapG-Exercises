package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.entities.MyEmployee;
import com.cg.service.EmployeeService;

@Controller
public class EmployeeController {
	
	@Autowired
	EmployeeService employeeService;
	
	@RequestMapping("/index")
	public String getHomePage(Model model)
	{
		model.addAttribute("empList",employeeService.loadAll());
		model.addAttribute("designations", new String[]{"System associate", "asssis associate", "Soft associate"});
		model.addAttribute("employee", new MyEmployee());
		return "index";
	}
	@RequestMapping(value="/save", method=RequestMethod.POST)
	public String saveEmployee(@ModelAttribute("employee") MyEmployee employee,Model model)
	{
		MyEmployee empRes=employeeService.save(employee);
		return "redirect:/index.html";
	}

}
