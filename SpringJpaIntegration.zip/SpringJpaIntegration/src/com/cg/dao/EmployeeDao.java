package com.cg.dao;

import java.util.List;

import com.cg.entities.MyEmployee;

public interface EmployeeDao {
	
	

	public abstract MyEmployee save(MyEmployee employee);
	
	public abstract List<MyEmployee> loadAll();

}
