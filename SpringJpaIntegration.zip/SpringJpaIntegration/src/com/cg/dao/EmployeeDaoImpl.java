package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.MyEmployee;
@Repository
public class EmployeeDaoImpl  implements EmployeeDao{
@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public MyEmployee save(MyEmployee employee) {
		// TODO Auto-generated method stub
		
		entityManager.persist(employee);
		entityManager.flush();
		return employee;
	}

	@Override
	public List<MyEmployee> loadAll() {
		// TODO Auto-generated method stub
		
		TypedQuery<MyEmployee> query=entityManager.createQuery("SELECT e from MyEmployee e", MyEmployee.class);
		
		return query.getResultList();
	}

}
