package com.product.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.product.bean.Product;
import com.product.dao.ProductDao;
import com.product.exception.ProductException;
@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductDao  productDao;
	@Override
	public List<Product> createProduct(Product pr) throws ProductException {
		try {
			productDao.save(pr);
	        return productDao.findAll();
	        }catch(Exception e) {
	            throw new ProductException(e.getMessage());
	        }
	}

	@Override
	public List<Product> updateProduct(String id, Product pr) throws ProductException {
		try
		{
			Optional<Product> optional=productDao.findById(id);
			if(optional.isPresent())
			{
				Product prod=optional.get();
				prod.setName(pr.getName());
				prod.setModel(pr.getModel());
				prod.setPrice(pr.getPrice());
				productDao.save(prod);
				return viewProducts();
			}
			else
			{
				throw new ProductException("Product with Id"+id+" does not exist");	
			}
		}
			catch(Exception e) {
	            throw new ProductException(e.getMessage());
			
	}
	}

	@Override
	public void deleteProduct(String id) throws ProductException {
		try
		{
			productDao.deleteById(id);
		}
		catch(Exception e)
		{
			throw new ProductException(e.getMessage());
		}
		
	}
		
	

	@Override
	public List<Product> viewProducts() throws ProductException {
		try
		{
			return productDao.findAll();
		}
		catch(Exception e)
		{
			throw new ProductException(e.getMessage());
		}
	
	}

	@Override
	public Product findProductById(String id) throws ProductException {
		try
		{
			return productDao.findById(id).get();
		}
		catch (Exception ex)
		{
			throw new ProductException(ex.getMessage());
		}
	}
	}



