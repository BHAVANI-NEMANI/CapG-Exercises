package com.product.service;

import java.util.List;

import com.product.bean.Product;
import com.product.exception.ProductException;

public interface ProductService {

	public List<Product> createProduct(Product pr) throws ProductException;
	public List<Product> updateProduct(String id, Product pr) throws ProductException;
	public void deleteProduct (String id) throws ProductException;
	public List<Product> viewProducts() throws ProductException;
	public Product findProductById(String id) throws ProductException;
	
}
